# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import json
import os

import xbmc
import xbmcaddon
import xbmcgui

try:
    import xbmcvfs
    translate = xbmcvfs.translatePath
except (ImportError, AttributeError):
    translate = xbmc.translatePath

try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus

VALIDADE_FILA = 6 * 60 * 60


def _texto(valor):
    if valor is None:
        return ''
    if isinstance(valor, bytes):
        try:
            return valor.decode('utf-8', 'ignore')
        except Exception:
            return ''
    try:
        return '%s' % valor
    except Exception:
        return ''


def _arquivo_fila():
    perfil = translate(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(_texto(perfil), 'fila_episodios.json')


def _ler_fila():
    caminho = _arquivo_fila()
    if not os.path.isfile(caminho):
        return {}
    try:
        with open(caminho, 'rb') as fh:
            dados = json.loads(fh.read().decode('utf-8'))
    except Exception:
        return {}
    return dados if isinstance(dados, dict) else {}


def _autoplay_ligado():
    return xbmcaddon.Addon().getSetting('autoplay') != 'false'


def _quote(valor):
    texto = _texto(valor)
    try:
        return quote_plus(texto)
    except Exception:
        try:
            return quote_plus(texto.encode('utf-8'))
        except Exception:
            return ''


def _proximo(fila, atual):
    itens = fila.get('itens')
    alvo = _texto(atual).strip()
    if not alvo or not isinstance(itens, list):
        return None
    try:
        quando = float(fila.get('atual_em') or 0)
    except Exception:
        quando = 0
    if quando and __import__('time').time() - quando > VALIDADE_FILA:
        return None
    urls = [_texto(item.get('url')).strip() for item in itens]
    if alvo not in urls:
        return None
    posicao = urls.index(alvo) + 1
    if posicao >= len(itens):
        return None
    episodio = itens[posicao]
    return episodio if isinstance(episodio, dict) else None


def _endereco(episodio):
    campos = [
        ('url', episodio.get('url')),
        ('mode', '16'),
        ('name', episodio.get('name')),
        ('iconimage', episodio.get('icon')),
        ('fanart', episodio.get('fanart')),
    ]
    partes = []
    for chave, valor in campos:
        partes.append('%s=%s' % (chave, _quote(valor)))
    return 'plugin://%s/?%s' % (xbmcaddon.Addon().getAddonInfo('id'), '&'.join(partes))


def _caminho(item):
    for nome in ('getPath', 'getfilename'):
        metodo = getattr(item, nome, None)
        if not metodo:
            continue
        try:
            return _texto(metodo())
        except Exception:
            continue
    return ''


def _ja_tem(playlist, endereco):
    try:
        total = int(playlist.size())
    except Exception:
        return False
    indice = 0
    while indice < total:
        try:
            if _caminho(playlist[indice]) == endereco:
                return True
        except Exception:
            pass
        indice += 1
    return False


def _tocando():
    try:
        return _texto(xbmc.Player().getPlayingFile())
    except Exception:
        return ''


def _tirar(playlist, enderecos, tocando):
    for endereco in list(enderecos):
        if not endereco or endereco == tocando:
            continue
        try:
            playlist.remove(endereco)
        except Exception:
            pass
        try:
            enderecos.remove(endereco)
        except ValueError:
            pass


def _item(episodio, endereco):
    nome = _texto(episodio.get('name')) or 'Próximo episódio'
    item = xbmcgui.ListItem(nome)
    icon = _texto(episodio.get('icon'))
    fanart = _texto(episodio.get('fanart'))
    try:
        item.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
    except Exception:
        if icon:
            try:
                item.setThumbnailImage(icon)
            except Exception:
                pass
    try:
        item.setProperty('IsPlayable', 'true')
    except Exception:
        pass
    try:
        item.setPath(endereco)
    except Exception:
        pass
    return item


def _sincronizar(nossos):
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    tocando = _tocando()
    if not _autoplay_ligado():
        _tirar(playlist, nossos, tocando)
        return
    fila = _ler_fila()
    episodio = _proximo(fila, fila.get('atual'))
    if not episodio:
        _tirar(playlist, nossos, tocando)
        return
    endereco = _endereco(episodio)
    if endereco in nossos or _ja_tem(playlist, endereco):
        if endereco not in nossos:
            nossos.append(endereco)
        return
    _tirar(playlist, nossos, tocando)
    try:
        playlist.add(endereco, _item(episodio, endereco))
        nossos.append(endereco)
    except Exception:
        pass


class _Player(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.pendente = False

    def onPlayBackStarted(self):
        self.pendente = True

    def onAVStarted(self):
        self.pendente = True


def principal():
    monitor = xbmc.Monitor()
    player = _Player()
    nossos = []
    while not monitor.abortRequested():
        if player.pendente:
            player.pendente = False
            if monitor.waitForAbort(1):
                break
            try:
                _sincronizar(nossos)
            except Exception:
                pass
        if monitor.waitForAbort(1):
            break


if __name__ == '__main__':
    try:
        principal()
    except Exception:
        pass
