# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui

try:
    import xbmcvfs
    translate = xbmcvfs.translatePath
except (ImportError, AttributeError):
    translate = xbmc.translatePath

try:
    from urllib.parse import quote_plus
except ImportError:
    from urllib import quote_plus

SEGUNDOS = {'0': 5, '1': 10, '2': 15, '3': 20, '4': 30}
VALIDADE_FILA = 6 * 60 * 60


def _texto(valor):
    if valor is None:
        return ''
    if isinstance(valor, bytes):
        try:
            return valor.decode('utf-8', 'ignore')
        except Exception:
            return ''
    try:
        return '%s' % valor
    except Exception:
        return ''


def _arquivo_fila():
    perfil = translate(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(_texto(perfil), 'fila_episodios.json')


def _ler_fila():
    caminho = _arquivo_fila()
    if not os.path.isfile(caminho):
        return {}
    try:
        with open(caminho, 'rb') as fh:
            dados = json.loads(fh.read().decode('utf-8'))
    except Exception:
        return {}
    return dados if isinstance(dados, dict) else {}


def _autoplay_ligado():
    return xbmcaddon.Addon().getSetting('autoplay') != 'false'


def _segundos():
    return SEGUNDOS.get(xbmcaddon.Addon().getSetting('autoplay_segundos'), 5)


def _proximo(fila, atual):
    itens = fila.get('itens')
    alvo = _texto(atual).strip()
    if not alvo or not isinstance(itens, list):
        return None
    try:
        quando = float(fila.get('atual_em') or 0)
    except Exception:
        quando = 0
    if quando and time.time() - quando > VALIDADE_FILA:
        return None
    urls = [_texto(item.get('url')).strip() for item in itens]
    if alvo not in urls:
        return None
    posicao = urls.index(alvo) + 1
    if posicao >= len(itens):
        return None
    episodio = itens[posicao]
    return episodio if isinstance(episodio, dict) else None


def _endereco(episodio):
    campos = [
        ('url', episodio.get('url')),
        ('mode', '16'),
        ('name', episodio.get('name')),
        ('iconimage', episodio.get('icon')),
        ('fanart', episodio.get('fanart')),
    ]
    partes = []
    for chave, valor in campos:
        partes.append('%s=%s' % (chave, quote_plus(_texto(valor).encode('utf-8'))))
    return 'plugin://%s/?%s' % (xbmcaddon.Addon().getAddonInfo('id'), '&'.join(partes))


def _contagem(monitor, nome, segundos):
    dialogo = xbmcgui.DialogProgress()
    dialogo.create('PRÓXIMO EPISÓDIO', '%s começa em %ss' % (nome, segundos))
    restante = segundos
    try:
        while restante > 0:
            if dialogo.iscanceled() or monitor.abortRequested():
                return False
            dialogo.update(
                int((segundos - restante) * 100 / segundos),
                '%s começa em %ss' % (nome, restante),
            )
            if monitor.waitForAbort(1):
                return False
            restante -= 1
    finally:
        dialogo.close()
    return True


def _tocar_proximo(monitor, player, atual):
    episodio = _proximo(_ler_fila(), atual)
    if not episodio:
        return
    nome = _texto(episodio.get('name')) or 'Próximo episódio'
    if not _contagem(monitor, nome, _segundos()):
        return
    endereco = _endereco(episodio)
    try:
        if player.isPlaying():
            player.stop()
    except Exception:
        pass
    if monitor.waitForAbort(1):
        return
    xbmc.executebuiltin('PlayMedia("%s")' % endereco)


def _atualizar_lista():
    try:
        pasta = xbmc.getInfoLabel('Container.FolderPath') or ''
    except Exception:
        return
    if pasta.startswith('plugin://%s' % xbmcaddon.Addon().getAddonInfo('id')):
        xbmc.executebuiltin('Container.Refresh')


def principal():
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    atual = None
    tratados = []
    reproduzindo = False
    tempo = 0.0
    total = 0.0

    while not monitor.abortRequested():
        try:
            if player.isPlayingVideo():
                alvo = _texto(_ler_fila().get('atual')).strip()
                if alvo and alvo != atual:
                    atual = alvo
                    tempo = 0.0
                    total = 0.0
                try:
                    tempo = float(player.getTime() or 0)
                    total = float(player.getTotalTime() or 0)
                except Exception:
                    pass
                reproduzindo = True
                if atual and atual not in tratados and _autoplay_ligado():
                    faltam = total - tempo
                    if total > 90 and 0 < faltam <= _segundos() + 1:
                        tratados.append(atual)
                        _tocar_proximo(monitor, player, atual)
            elif reproduzindo:
                reproduzindo = False
                terminou = total > 90 and tempo >= total * 0.9
                if terminou and atual and atual not in tratados and _autoplay_ligado():
                    tratados.append(atual)
                    _tocar_proximo(monitor, player, atual)
                else:
                    _atualizar_lista()
                atual = None
            del tratados[:-10]
        except Exception:
            pass
        if monitor.waitForAbort(1):
            break


if __name__ == '__main__':
    try:
        principal()
    except Exception:
        pass
